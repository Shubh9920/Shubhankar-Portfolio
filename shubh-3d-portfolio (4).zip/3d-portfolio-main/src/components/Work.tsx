import { useState, useCallback } from "react";
import "./styles/Work.css";
import WorkImage from "./WorkImage";
import { MdArrowBack, MdArrowForward } from "react-icons/md";

const projects = [
  {
    title: "PrintBot",
    category: "Print-Shop Automation",
    tools: "QR Upload, WhatsApp Bot, Windows Print Agent, Node.js, Python",
    image: "/images/printbot.webp",
    link: "https://github.com/Shubh9920",
  },
  {
    title: "Smart Hostel Energy Monitor",
    category: "IoT + AI Energy Monitoring",
    tools: "ESP32, Google Sheets, Apps Script, scikit-learn, WhatsApp Alerts, Looker Studio",
    image: "/images/shem.webp",
    link: "https://visionary-kheer-a7e93b.netlify.app/",
  },
  {
    title: "INCT SMS",
    category: "Student Registration & Course Management",
    tools: "React, TypeScript, Tailwind CSS, Vite, React Router, Admin Dashboard",
    image: "/images/inct-sms.webp",
    link: "https://inctsmss.netlify.app/",
  },
  {
    title: "FinanceAI – Smart Money Tracker",
    category: "Progressive Web App",
    tools: "PWA, Expense Tracking, CSV Import (GPay / PhonePe / Paytm), AI Finance Advisor",
    image: "/images/financeai.webp",
    link: "https://financeappsh.netlify.app/",
  },
  {
    title: "Employee Salary Predictor",
    category: "Machine Learning Web App",
    tools: "Python, LightGBM, scikit-learn, Streamlit",
    image: "/images/salary-predictor.webp",
    link: "https://github.com/Shubh9920/Employee-Salary-Predication-Shubhankar",
  },
];

const Work = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const goToSlide = useCallback(
    (index: number) => {
      if (isAnimating) return;
      setIsAnimating(true);
      setCurrentIndex(index);
      setTimeout(() => setIsAnimating(false), 500);
    },
    [isAnimating]
  );

  const goToPrev = useCallback(() => {
    const newIndex =
      currentIndex === 0 ? projects.length - 1 : currentIndex - 1;
    goToSlide(newIndex);
  }, [currentIndex, goToSlide]);

  const goToNext = useCallback(() => {
    const newIndex =
      currentIndex === projects.length - 1 ? 0 : currentIndex + 1;
    goToSlide(newIndex);
  }, [currentIndex, goToSlide]);

  return (
    <div className="work-section" id="work">
      <div className="work-container section-container">
        <h2>
          My <span>Work</span>
        </h2>

        <div className="carousel-wrapper">
          {/* Navigation Arrows */}
          <button
            className="carousel-arrow carousel-arrow-left"
            onClick={goToPrev}
            aria-label="Previous project"
            data-cursor="disable"
          >
            <MdArrowBack />
          </button>
          <button
            className="carousel-arrow carousel-arrow-right"
            onClick={goToNext}
            aria-label="Next project"
            data-cursor="disable"
          >
            <MdArrowForward />
          </button>

          {/* Slides */}
          <div className="carousel-track-container">
            <div
              className="carousel-track"
              style={{
                transform: `translateX(-${currentIndex * 100}%)`,
              }}
            >
              {projects.map((project, index) => (
                <div className="carousel-slide" key={index}>
                  <div className="carousel-content">
                    <div className="carousel-info">
                      <div className="carousel-number">
                        <h3>0{index + 1}</h3>
                      </div>
                      <div className="carousel-details">
                        <h4>{project.title}</h4>
                        <p className="carousel-category">
                          {project.category}
                        </p>
                        <div className="carousel-tools">
                          <span className="tools-label">Tools & Features</span>
                          <p>{project.tools}</p>
                        </div>
                      </div>
                    </div>
                    <div className="carousel-image-wrapper">
                      <WorkImage
                        image={project.image}
                        alt={project.title}
                        link={project.link}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dot Indicators */}
          <div className="carousel-dots">
            {projects.map((_, index) => (
              <button
                key={index}
                className={`carousel-dot ${index === currentIndex ? "carousel-dot-active" : ""
                  }`}
                onClick={() => goToSlide(index)}
                aria-label={`Go to project ${index + 1}`}
                data-cursor="disable"
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Work;
