import { MdArrowOutward, MdCopyright } from "react-icons/md";
import "./styles/Contact.css";

const Contact = () => {
  return (
    <div className="contact-section section-container" id="contact">
      <div className="contact-container">
        <h3>Contact</h3>
        <div className="contact-flex">
          <div className="contact-box">
            <h4>Connect</h4>
            <p>
              <a href="mailto:shubh255345@gmail.com" data-cursor="disable">
                shubh255345@gmail.com
              </a>
            </p>
            <p>
              <a
                href="https://github.com/Shubh9920"
                target="_blank"
                rel="noreferrer"
                data-cursor="disable"
              >
                GitHub — Shubh9920
              </a>
            </p>
            <h4>Education</h4>
            <p>
              MCA, School of Management Sciences, Varanasi (AKTU) — 2025–2027
            </p>
            <p>
              BCA, Rajarshi School of Management &amp; Technology, MGKV Varanasi
              — 2025
            </p>
          </div>
          <div className="contact-box">
            <h4>Social</h4>
            <a
              href="https://github.com/Shubh9920"
              target="_blank"
              rel="noreferrer"
              data-cursor="disable"
              className="contact-social"
            >
              GitHub <MdArrowOutward />
            </a>
            <a
              href="mailto:shubh255345@gmail.com"
              data-cursor="disable"
              className="contact-social"
            >
              Email <MdArrowOutward />
            </a>
          </div>
          <div className="contact-box">
            <h2>
              Designed and Developed <br /> by <span>Shubhankar Kumar Gupta</span>
            </h2>
            <h5>
              <MdCopyright /> 2026
            </h5>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
