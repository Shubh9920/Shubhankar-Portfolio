import "./styles/Career.css";

const Career = () => {
  return (
    <div className="career-section section-container">
      <div className="career-container">
        <h2>
          My journey <span>&</span>
          <br /> experience
        </h2>
        <div className="career-info">
          <div className="career-timeline">
            <div className="career-dot"></div>
          </div>
          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>Developer</h4>
                <h5>Independent Projects</h5>
              </div>
              <h3>NOW</h3>
            </div>
            <p>
              Building tools for real-life problems: PrintBot for print shops, a hostel energy monitor, a student registration system and a finance tracker.
            </p>
          </div>
          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>MCA</h4>
                <h5>SMS Varanasi · AKTU</h5>
              </div>
              <h3>2025–27</h3>
            </div>
            <p>
              Master of Computer Applications, currently in the second semester, alongside my own projects.
            </p>
          </div>
          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>AI Intern</h4>
                <h5>AICTE · Edunet Foundation · IBM SkillsBuild</h5>
              </div>
              <h3>2025</h3>
            </div>
            <p>
              Six-week internship on Artificial Intelligence (June to July 2025). Also completed C-DAC and IIT Roorkee's one-month Quantum Computing course in May 2025.
            </p>
          </div>
          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>BCA</h4>
                <h5>Rajarshi School of Management &amp; Technology</h5>
              </div>
              <h3>2025</h3>
            </div>
            <p>
              Bachelor of Computer Applications at Mahatma Gandhi Kashi Vidyapeeth, Varanasi. Built the base in programming and web technologies.
            </p>
          </div>
          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>Design Intern</h4>
                <h5>Delhi Technological University</h5>
              </div>
              <h3>2024</h3>
            </div>
            <p>
              Four-week Visual Story Telling internship with the Centre for Industrial Design and Ergonomics (July 2024).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Career;
