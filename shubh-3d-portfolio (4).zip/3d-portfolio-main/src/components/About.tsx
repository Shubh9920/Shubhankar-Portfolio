import "./styles/About.css";

const About = () => {
  return (
    <div className="about-section" id="about">
      <div className="about-me">
        <h3 className="title">About Me</h3>
        <p className="para">
          Hello! I'm <strong>Shubhankar</strong>, a <strong>Developer</strong>{" "}
          from <strong>Varanasi</strong>, currently pursuing a{" "}
          <strong>Master of Computer Applications (MCA)</strong> at the{" "}
          <strong>School of Management Sciences, Varanasi</strong>. I
          completed my BCA in 2025 before this.
        </p>
        <p className="para">
          I like working on <strong>real-life problems</strong>, either to
          solve them or at least make them smaller. I've built{" "}
          <strong>PrintBot</strong>, which lets a print shop take orders over
          WhatsApp and QR, the <strong>Smart Hostel Energy Monitor</strong>,
          which tracks hostel electricity use and sends alerts when it spikes,{" "}
          <strong>INCT SMS</strong> for student registrations, and{" "}
          <strong>FinanceAI</strong> to keep track of everyday spending.
        </p>
        <p className="para">
          Along the way I've done an{" "}
          <span className="about-mono">AI internship</span> with{" "}
          <strong>AICTE, Edunet Foundation and IBM SkillsBuild</strong>, a{" "}
          <strong>Visual Story Telling</strong> internship at{" "}
          <strong>DTU</strong>, and a one-month{" "}
          <strong>Quantum Computing</strong> course by C-DAC and IIT Roorkee. I
          mostly work with <span className="about-mono">Web Development</span>,{" "}
          <span className="about-mono">Python</span> and{" "}
          <span className="about-mono">Applied AI</span>, and when I'm not
          coding it's cricket, gaming or travelling.
        </p>
        <div className="about-chips">
          <span>🎓 MCA — SMS Varanasi</span>
          <span>🛠 Solving real-life problems</span>
          <span>🌱 Open to Internships / Full-time</span>
        </div>
      </div>
    </div>
  );
};

export default About;
